"version.qtlDesign" <-
function()
  {
    0.92
  }

