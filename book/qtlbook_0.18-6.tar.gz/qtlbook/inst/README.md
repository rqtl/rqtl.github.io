### R/qtlbook

[![Build Status](https://travis-ci.org/kbroman/qtlbook.svg?branch=master)](https://travis-ci.org/kbroman/qtlbook)
[![CRAN_Status_Badge](http://www.r-pkg.org/badges/version/qtlbook)](https://cran.r-project.org/package=qtlbook)

[Karl W Broman](http://kbroman.org)

[R/qtlbook](https://github.com/kbroman/qtlbook) is an R package with
data sets for the book, [A Guide to QTL Mapping with R/qtl](http://www.rqtl.org/book).

### License

This package is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License, version 3, as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but
without any warranty; without even the implied warranty of
merchantability or fitness for a particular purpose.  See the GNU
General Public License for more details.

A copy of the GNU General Public License, version 3, is available at
<https://www.r-project.org/Licenses/GPL-3>
